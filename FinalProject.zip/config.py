
# константы для подключения MySQL
MYSQL_CONFIG = {
    'host': 'ich-db.edu.itcareerhub.de',
    'user': 'ich1',
    'password': 'password',
    'database': 'sakila',
    'cursorclass': None  # устанавливается в коде
}

# константы для подключения MongoDB
MONGODB_URI = "mongodb+srv://kurgak87:PB7u4W3LqAhyIrW5@cluster0.pvksblx.mongodb.net/"
MONGODB_DB = "final_project"
MONGODB_COLLECTION = "final_project_170225_AnnaKurgak"

# константа для SQL запроса, количество фильмов для вывода
DEFAULT_LIMIT = 10
